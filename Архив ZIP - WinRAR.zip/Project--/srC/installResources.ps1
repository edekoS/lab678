# src/installResources.ps1
pip install pyinstaller
pip install pyqt5
pip install pyyaml
